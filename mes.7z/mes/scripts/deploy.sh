#!/bin/bash

# Скрипт для развёртывания на продакшен

echo "🚀 Развёртывание на продакшен..."

# Проверка наличия .env файла
if [ ! -f .env ]; then
    echo "❌ Файл .env не найден. Создайте его из .env.example"
    echo "   cp .env.example .env"
    echo "   nano .env"
    exit 1
fi

# Проверка критических переменных
source .env

if [ -z "$SECRET_KEY" ] || [ "$SECRET_KEY" == "your-super-secret-jwt-key-min-32-characters" ]; then
    echo "❌ SECRET_KEY не настроен в .env"
    exit 1
fi

if [ -z "$POSTGRES_PASSWORD" ] || [ "$POSTGRES_PASSWORD" == "your-secure-postgres-password" ]; then
    echo "❌ POSTGRES_PASSWORD не настроен в .env"
    exit 1
fi

echo "✅ Переменные окружения настроены"

# Создание бэкапа перед обновлением
if docker ps | grep -q mes_postgres; then
    echo "💾 Создание бэкапа перед обновлением..."
    ./scripts/backup.sh
fi

# Остановка старых контейнеров
echo "⏹️  Остановка старых контейнеров..."
docker-compose -f docker-compose.prod.yml down

# Получение последних изменений
echo "📥 Получение последних изменений..."
git pull

# Сборка и запуск
echo "🔨 Сборка и запуск контейнеров..."
docker-compose -f docker-compose.prod.yml up -d --build

# Ожидание запуска
echo "⏳ Ожидание запуска сервисов..."
sleep 10

# Проверка статуса
echo "✅ Проверка статуса сервисов..."
docker-compose -f docker-compose.prod.yml ps

echo ""
echo "🎉 Развёртывание завершено!"
echo ""
echo "Для просмотра логов: docker-compose -f docker-compose.prod.yml logs -f"

