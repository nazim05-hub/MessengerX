# 💬 PWA Messenger

Современный, полнофункциональный PWA-мессенджер с поддержкой WebRTC для аудио/видео звонков.

## ✨ Возможности

### 🔐 Аутентификация
- Регистрация по email
- Подтверждение email
- JWT авторизация
- Refresh токены
- Выход из системы

### 💬 Чаты
- Личные и групповые чаты
- Отправка сообщений в реальном времени (WebSocket)
- Статусы онлайн/оффлайн
- Индикатор набора текста
- Отправка текста, изображений, видео, документов
- Прикрепление файлов
- Реакции на сообщения
- Отметка "прочитано"
- Удаление и редактирование сообщений
- Push-уведомления

### 👤 Профиль пользователя
- Фото профиля
- Статус
- Никнейм
- Номер телефона (опционально)
- Настройки приватности

### 📞 Аудио/Видео Звонки (WebRTC)
- Создание звонка
- Ответ на звонок
- Отклонение звонка
- Переключение камеры
- Отключение микрофона/камеры
- Демонстрация экрана
- Групповые звонки
- STUN/TURN поддержка

### 📱 PWA
- Офлайн поддержка (IndexedDB + Service Worker)
- Push-уведомления
- Установка на телефон
- Адаптивный дизайн
- Тёмная/светлая тема

## 🛠 Технологии

### Frontend
- **React** - UI библиотека
- **Vite** - Быстрый сборщик
- **TypeScript** - Типизация
- **Mantine UI** - Компоненты и стили
- **Zustand** - Управление состоянием
- **React Query** - Кэширование и синхронизация данных
- **WebSocket** - Реальное время
- **WebRTC** - Аудио/видео звонки
- **IndexedDB** - Офлайн хранилище
- **Service Worker** - PWA функциональность

### Backend
- **Python** - Язык программирования
- **FastAPI** - Веб-фреймворк
- **PostgreSQL** - Основная база данных
- **SQLAlchemy** - ORM
- **Redis** - Кэш и онлайн-статусы
- **WebSockets** - Реальное время
- **JWT** - Авторизация
- **Uvicorn** - ASGI сервер

### Инфраструктура
- **Docker** - Контейнеризация
- **Docker Compose** - Оркестрация
- **Coturn** - TURN/STUN сервер для WebRTC
- **Caddy** - Reverse proxy и SSL

## 🚀 Быстрый старт

### Требования
- Docker и Docker Compose
- Node.js 20+ (для локальной разработки)
- Python 3.11+ (для локальной разработки)

### Установка и запуск

#### 1. Клонирование репозитория
```bash
git clone <repository-url>
cd mes
```

#### 2. Настройка окружения

##### Backend
Скопируйте `.env.example` в `.env` и настройте переменные:
```bash
cd backend
cp .env.example .env
# Отредактируйте .env файл
```

Важные переменные:
```env
DATABASE_URL=postgresql://messenger:messenger_password@postgres:5432/messenger
REDIS_URL=redis://redis:6379
SECRET_KEY=your-super-secret-key-change-in-production
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASSWORD=your-app-password
```

##### Frontend
Создайте `.env` файл в папке `frontend`:
```bash
cd frontend
cat > .env << EOL
VITE_API_URL=http://localhost:8000
VITE_WS_URL=ws://localhost:8000
EOL
```

##### Coturn
Отредактируйте `coturn/turnserver.conf` и замените:
```
external-ip=YOUR_PUBLIC_IP
```
на ваш публичный IP адрес.

#### 3. Запуск с Docker Compose

```bash
# Из корневой директории проекта
docker-compose up -d
```

Это запустит все сервисы:
- **Frontend**: http://localhost:3000
- **Backend API**: http://localhost:8000
- **PostgreSQL**: localhost:5432
- **Redis**: localhost:6379
- **Coturn**: UDP 3478, 5349

#### 4. Проверка работы

Откройте браузер и перейдите по адресу:
```
http://localhost:3000
```

## 🔧 Разработка

### Запуск Backend локально

```bash
cd backend

# Создание виртуального окружения
python -m venv venv
source venv/bin/activate  # Linux/Mac
# или
venv\Scripts\activate  # Windows

# Установка зависимостей
pip install -r requirements.txt

# Запуск сервера
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

### Запуск Frontend локально

```bash
cd frontend

# Установка зависимостей
npm install

# Запуск dev сервера
npm run dev
```

Frontend будет доступен по адресу: http://localhost:3000

### Миграции базы данных

```bash
cd backend

# Создание миграции
alembic revision --autogenerate -m "Description"

# Применение миграций
alembic upgrade head
```

## 📦 Продакшн

### Подготовка к продакшену

1. **Настройте домены в Caddyfile**:
```
yourdomain.com {
    reverse_proxy frontend:3000
}

api.yourdomain.com {
    reverse_proxy backend:8000
}
```

2. **Обновите переменные окружения**:
```env
# Backend .env
SECRET_KEY=<сгенерируйте надёжный ключ>
FRONTEND_URL=https://yourdomain.com

# Frontend .env
VITE_API_URL=https://api.yourdomain.com
VITE_WS_URL=wss://api.yourdomain.com
```

3. **Настройте Coturn** с вашим публичным IP

4. **Соберите продакшн образы**:
```bash
docker-compose -f docker-compose.prod.yml up -d --build
```

### SSL сертификаты

Caddy автоматически получит SSL сертификаты от Let's Encrypt при использовании доменных имён.

## 🧪 Тестирование

### Backend
```bash
cd backend
pytest
```

### Frontend
```bash
cd frontend
npm run test
```

## 📱 Использование как PWA

### На мобильных устройствах

1. Откройте приложение в браузере
2. В меню браузера выберите "Добавить на главный экран"
3. Приложение установится как PWA

### Push-уведомления

Приложение запросит разрешение на отправку уведомлений при первом запуске.

## 🗂 Структура проекта

```
mes/
├── backend/                 # Backend приложение
│   ├── routers/            # API endpoints
│   ├── models.py           # SQLAlchemy модели
│   ├── schemas.py          # Pydantic схемы
│   ├── auth.py             # Аутентификация
│   ├── database.py         # База данных
│   ├── websocket_manager.py # WebSocket менеджер
│   ├── main.py             # Главный файл FastAPI
│   ├── requirements.txt    # Python зависимости
│   └── Dockerfile          # Docker образ
├── frontend/               # Frontend приложение
│   ├── src/
│   │   ├── components/    # React компоненты
│   │   ├── pages/         # Страницы
│   │   ├── stores/        # Zustand stores
│   │   ├── services/      # API и сервисы
│   │   ├── types/         # TypeScript типы
│   │   ├── config/        # Конфигурация
│   │   ├── App.tsx        # Главный компонент
│   │   └── main.tsx       # Точка входа
│   ├── public/            # Статические файлы
│   ├── package.json       # Node зависимости
│   ├── vite.config.ts     # Vite конфигурация
│   └── Dockerfile         # Docker образ
├── coturn/                # Coturn конфигурация
│   └── turnserver.conf
├── docker-compose.yml     # Docker Compose файл
├── Caddyfile             # Caddy конфигурация
└── README.md             # Документация
```

## 🐛 Решение проблем

### WebSocket не подключается
- Проверьте, что backend запущен
- Убедитесь, что токен валиден
- Проверьте CORS настройки

### WebRTC не работает
- Настройте TURN сервер с вашим публичным IP
- Убедитесь, что порты 3478 и 5349 открыты
- Проверьте, что браузер имеет доступ к камере/микрофону

### База данных не подключается
- Проверьте, что PostgreSQL контейнер запущен
- Убедитесь, что DATABASE_URL правильный

## 📄 Лицензия

MIT

## 👥 Автор

Создано с ❤️ для современных коммуникаций

## 🙏 Благодарности

- **FastAPI** - за отличный веб-фреймворк
- **Mantine** - за красивые компоненты
- **React** - за мощную UI библиотеку
- **Docker** - за простоту развёртывания

