# ⚡ Быстрый старт

Запуск приложения за 5 минут!

## Локальная разработка

### 1. Клонирование репозитория
```bash
git clone <repository-url>
cd mes
```

### 2. Запуск через Docker Compose
```bash
# Запустить все сервисы
docker-compose up -d

# Проверить статус
docker-compose ps

# Просмотр логов
docker-compose logs -f
```

### 3. Открыть приложение
```
Frontend: http://localhost:3000
Backend API: http://localhost:8000
API Docs: http://localhost:8000/docs
```

### 4. Первая регистрация

1. Откройте http://localhost:3000
2. Нажмите "Зарегистрироваться"
3. Заполните форму:
   - Email: test@example.com
   - Username: testuser
   - Password: password123
4. Войдите в систему

### 5. Создание первого чата

1. После входа нажмите кнопку "+"
2. Выберите пользователя (нужно зарегистрировать второго пользователя)
3. Начните общение!

## Остановка и очистка

```bash
# Остановить все сервисы
docker-compose down

# Остановить и удалить volumes (БД и данные)
docker-compose down -v

# Полная очистка
docker-compose down -v --rmi all
```

## Быстрые команды

### Просмотр логов конкретного сервиса
```bash
docker-compose logs -f backend
docker-compose logs -f frontend
docker-compose logs -f postgres
```

### Перезапуск сервиса
```bash
docker-compose restart backend
docker-compose restart frontend
```

### Доступ к базе данных
```bash
docker exec -it mes_postgres psql -U messenger
```

### Доступ к Redis CLI
```bash
docker exec -it mes_redis redis-cli
```

## Разработка без Docker

### Backend

```bash
cd backend

# Создать виртуальное окружение
python -m venv venv
source venv/bin/activate  # Linux/Mac
# или venv\Scripts\activate  # Windows

# Установить зависимости
pip install -r requirements.txt

# Запустить сервер
uvicorn main:app --reload
```

### Frontend

```bash
cd frontend

# Установить зависимости
npm install

# Запустить dev сервер
npm run dev
```

## Тестирование

### Тестовые пользователи

Зарегистрируйте два тестовых аккаунта:

**Пользователь 1:**
- Email: alice@example.com
- Username: alice
- Password: password123

**Пользователь 2:**
- Email: bob@example.com
- Username: bob
- Password: password123

### Тест чата

1. Откройте два браузера (или инкогнито окна)
2. Войдите как alice в первом
3. Войдите как bob во втором
4. Alice создаёт чат с bob
5. Отправьте сообщения туда-сюда

### Тест звонков

1. В чате нажмите иконку телефона (аудио) или камеры (видео)
2. Примите звонок во втором окне
3. Протестируйте:
   - Mute/unmute микрофона
   - Включение/выключение камеры (для видео)
   - Демонстрацию экрана
   - Завершение звонка

## Проблемы?

### Порты заняты
```bash
# Проверить, какой процесс использует порт
sudo lsof -i :3000
sudo lsof -i :8000

# Убить процесс
sudo kill -9 <PID>
```

### Docker проблемы
```bash
# Перезапустить Docker
sudo systemctl restart docker

# Очистить Docker кэш
docker system prune -a
```

### База данных не создаётся
```bash
# Удалить volume и пересоздать
docker-compose down -v
docker-compose up -d postgres
docker-compose logs postgres
```

## Следующие шаги

- Прочитайте [README.md](README.md) для полной документации
- Изучите [DEPLOYMENT.md](DEPLOYMENT.md) для развёртывания на продакшене
- Настройте SMTP для email-подтверждения
- Настройте TURN сервер для WebRTC через NAT

Удачной разработки! 🚀

