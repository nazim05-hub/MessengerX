# 🤝 Участие в разработке

Спасибо за интерес к проекту! Мы приветствуем любой вклад.

## 🔰 Начало работы

1. **Fork репозитория**
   ```bash
   # Нажмите кнопку "Fork" на GitHub
   ```

2. **Клонируйте ваш fork**
   ```bash
   git clone https://github.com/YOUR_USERNAME/mes.git
   cd mes
   ```

3. **Создайте ветку для изменений**
   ```bash
   git checkout -b feature/amazing-feature
   ```

4. **Настройте окружение**
   ```bash
   docker-compose up -d
   ```

## 📝 Правила кода

### Backend (Python)

- Следуйте PEP 8
- Используйте type hints
- Документируйте функции с помощью docstrings
- Пишите тесты для новой функциональности

```python
def create_user(user_data: UserCreate, db: Session) -> User:
    """
    Создаёт нового пользователя в базе данных.
    
    Args:
        user_data: Данные для создания пользователя
        db: Сессия базы данных
        
    Returns:
        Созданный пользователь
        
    Raises:
        ValueError: Если пользователь уже существует
    """
    pass
```

### Frontend (TypeScript/React)

- Используйте TypeScript для всех файлов
- Функциональные компоненты с хуками
- Именуйте компоненты в PascalCase
- Именуйте файлы так же, как компоненты

```typescript
// Good
export function UserProfile({ user }: UserProfileProps) {
  return <div>...</div>;
}

// Bad
export default function userProfile(props: any) {
  return <div>...</div>;
}
```

### Git Commits

Используйте семантические коммиты:

```bash
feat: добавить поддержку групповых звонков
fix: исправить баг с отправкой сообщений
docs: обновить README
style: форматирование кода
refactor: переработать WebSocket менеджер
test: добавить тесты для auth endpoints
chore: обновить зависимости
```

## 🧪 Тестирование

### Backend

```bash
cd backend
pytest
```

### Frontend

```bash
cd frontend
npm test
```

## 📤 Pull Request

1. **Убедитесь, что ваш код работает**
   ```bash
   # Запустите все тесты
   cd backend && pytest
   cd ../frontend && npm test
   ```

2. **Зафиксируйте изменения**
   ```bash
   git add .
   git commit -m "feat: добавить новую функцию"
   ```

3. **Push в ваш fork**
   ```bash
   git push origin feature/amazing-feature
   ```

4. **Создайте Pull Request на GitHub**
   - Опишите ваши изменения
   - Добавьте скриншоты если это UI изменения
   - Укажите связанные issues

## 🐛 Сообщение о багах

При создании issue укажите:

- **Описание проблемы**
- **Шаги для воспроизведения**
- **Ожидаемое поведение**
- **Фактическое поведение**
- **Скриншоты** (если применимо)
- **Окружение**:
  - ОС
  - Браузер (для фронтенда)
  - Версия Python (для бэкенда)

## 💡 Предложение функциональности

Создайте issue с тегом `enhancement` и опишите:

- **Описание функции**
- **Зачем это нужно**
- **Как это должно работать**
- **Альтернативные решения**

## 📋 Checklist перед PR

- [ ] Код соответствует стилю проекта
- [ ] Добавлены/обновлены тесты
- [ ] Все тесты проходят
- [ ] Обновлена документация
- [ ] Нет конфликтов с main веткой
- [ ] PR имеет понятное описание

## 🎯 Приоритетные задачи

Смотрите issues с тегами:
- `good first issue` - для новичков
- `help wanted` - требуется помощь
- `high priority` - важные задачи

## 💬 Вопросы?

- Создайте issue с тегом `question`
- Пишите в discussions на GitHub

Спасибо за ваш вклад! ❤️

